package featurebdd;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
    features = "src/test/java/featurebdd/login.feature",
    glue = "featurebdd",
    // Specify the correct Main class
    // Use io.cucumber.core.cli.Main instead of deprecated io.cucumber.core.cli.Main
    // Make sure to use cucumber.api.junit.Cucumber instead of cucumber.junit.Cucumber
    // Use junit-platform instead of junit
    // Use io.cucumber.junit.platform.engine.Cucumber instead of deprecated io.cucumber.junit.Cucumber
    plugin = {"pretty", "html:target/cucumber-reports"},
    name = "io.cucumber.core.cli.Main"
)
public class TestRunner {
}
