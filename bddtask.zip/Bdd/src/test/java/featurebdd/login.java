package featurebdd;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import static org.junit.Assert.assertEquals;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class login {
    WebDriver driver;
    String actualErrorMessage;
    

    @Given("User is on Amazon Home Page")
    public void user_is_on_amazon_home_page() {
    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\vignesh\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe\\");
        driver = new ChromeDriver();
        driver.get("https://www.amazon.com");
    }

    @When("User navigates to Login Page")
    public void user_navigates_to_login_page() {
        WebElement signInButton = driver.findElement(By.xpath("//span[@id='nav-link-accountList-nav-line-1']"));
        signInButton.click();
    }

    @Then("User enters {string} and {string}")
    public void user_enters_email_and_password(String email, String password) {
        WebElement emailInput = driver.findElement(By.xpath("//input[@id='ap_email']"));
        emailInput.sendKeys("mahasadha201@gmail.com");
        WebElement continueButton = driver.findElement(By.xpath("//input[@id='continue']"));
        continueButton.click();
        WebElement passwordInput = driver.findElement(By.xpath("//input[@id='ap_password']"));
        passwordInput.sendKeys("ssvm@4036");
    }

    @Then("Keeping case as {string}")
    public void keeping_case_as(String caseType) {
    	
            // Additional logic for case handling
            if (caseType.equals("UpperCase")) {
                // Convert email and password to uppercase
                WebElement emailInput = driver.findElement(By.xpath("//input[@id='ap_email']"));
                WebElement passwordInput = driver.findElement(By.xpath("//input[@id='ap_password']"));
                emailInput.sendKeys(emailInput.getAttribute("value").toUpperCase());
                passwordInput.sendKeys(passwordInput.getAttribute("value").toUpperCase());
            }
        }

    @Then("User should get logged in successfully if {string} is valid")
    public void user_should_get_logged_in_successfully_if_valid_is_valid(String caseType) {
        WebElement signInSubmitButton = driver.findElement(By.xpath("//input[@id='signInSubmit']"));
        signInSubmitButton.click();
        if (caseType.equals("Valid")) {
            WebElement loggedInUser = driver.findElement(By.xpath("//span[@id='nav-link-accountList-nav-line-1']"));
            assertEquals("Hello, mahasadha201@gmail.com", loggedInUser.getText());
        }
    }

    @Then("User should see the error message if {string} is invalid")
    public void user_should_see_the_error_message_if_invalid_is_invalid(String caseType) {
        if (caseType.equals("Invalid")) {
            WebElement errorMessage = driver.findElement(By.xpath("//div[@class='a-alert-content']"));
            actualErrorMessage = errorMessage.getText();
        }
    }

    @Then("Then User is redirected back to the login page and prompted to provide correct credentials if login is {string}")
    public void then_user_is_redirected_back_to_the_login_page_and_prompted_to_provide_correct_credentials_if_login_is_invalid(String caseType) {
        if (caseType.equals("Invalid")) {
            assertEquals("Invalid login attempt. Error message: ExpectedErrorMessage", actualErrorMessage);
        }
        driver.quit();
    }
    
}


